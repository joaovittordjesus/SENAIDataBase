<?php
header('Location: php/index.php');
exit;
?>
